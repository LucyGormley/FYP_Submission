import numpy as np
import os
import nltk
import re
from nltk.tokenize import sent_tokenize
from nltk.corpus import stopwords

#os.chdir('C:\\Path\\To\\File')
os.chdir('C:\\Users\\Lucy\\College\\4th Year\\FYP\\Summarizer')
os.listdir()
#filename='Parasite_Pos_Reviews.txt'
#filename='Parasite_Neg_Reviews.txt'
#filename='Joker_Pos_Reviews.txt'
#filename='Joker_Neg_Reviews.txt'
filename='Parasite_3.txt' # reads in text file of reviews
file=open(filename,"r")

text = file.read() # read in reveiws
# stemmer used to focus on main part of word e.g. eliminating repetitive ing, ed, s, add ons that dont add meanings to words
stemmer = nltk.stem.SnowballStemmer("english") 
def tokenize_sentences(text): # function to process sentences  
    sentence_tokens = sent_tokenize(text) # splits text into separate sentences    
    cleaned_sentences = [] # creates list to store sentences after processing 
    stopwords_list = stopwords.words('english') #stores stopwords imported from nltk library
    for sentence in sentence_tokens: # loops through each sentence
        sentence = sentence.lower() # make sentences lowercase
        sentence = sentence.replace('\n',' ') # replaces next line notation with blank space 
        sentence = sentence.replace('_',' ') # replaces _ with blank space
        sentence = re.sub(r'[^\w\s]','', sentence)# removes characters that are not words
        sentence = re.sub(r'[0-9]','', sentence) # removes figures - have no semantic meaning
        sentence = stemmer.stem(sentence) # leaves the stem of words 
        sentence = [w for w in sentence.split() if not w in stopwords_list] # joins words back into sentences, if they are not considered a stopword
        sentence = " ".join(sentence)
        cleaned_sentences.append(sentence) # adds processed sentence to list of cleaned sentences
    return cleaned_sentences
 
sentences = tokenize_sentences(text) # stores list of cleaned sentences
joined_sentences = " ".join(sentences) # join all sentences together 
split_sentences = joined_sentences.split() #separates each word to calculate tf-idf score 
unique_words = list(set(split_sentences))
num_unique_words = len(unique_words) # counts all unique words (excl. stopwords)
num_sentences = len(sentences) # counts all sentences

word_count_dict = {} # stores and calculates number of words in each sentence
for word in unique_words:
    word_count_dict[word] = split_sentences.count(word)
    
tf_dict = {} # stores and calculates the tf value on each word
for word in unique_words:
    tf_dict[word] = word_count_dict[word] / num_unique_words
    
idf_dict = {} # stores and calculates the idf value on each word
for word in unique_words: # loops through all words in list of unique words
    num_times_word_appears = 0 # sets variable to 0
    for sentence in sentences: # loops through sentences
        if word in sentence.split():
            num_times_word_appears += 1 # increments variable by 1   
    idf_dict[word] = np.log10(num_sentences/num_times_word_appears) # calculates idf and stores in idf dictionary
    
tf_idf_dict = {} # stores and calculates tf-idf value
for word in unique_words:
    tf_idf_dict[word] = tf_dict[word] * idf_dict[word] # multiplies tf value by idf value on each word   

sentence_importances = np.zeros(num_sentences)
for sentence_id, sentence in enumerate(sentences):    
    importance = 0 # set importance to 0
    for word in sentence.split():       
        importance += tf_idf_dict[word] # importance stores the tf-idf score
        
    #should take into account longer and shorter sentences
    if len(sentence.split()) > 0:
        #divides importance with the length of sentence and assigns result to the importance score value
        #If element is a sentence i.e. greater than 0, 
        importance /= len(sentence.split()) 
    
    if len(sentence.split()) < 3:  
        importance = 0 # very short sentences not considered important
    
    sentence_importances[sentence_id] = importance

sorted_importance_ids = np.argsort(sentence_importances)[::-1]#sorts senetnces in descending order, starting with highest scoring first
top_n_sentences = int(num_sentences * 0.01) #stores top 1% highest scoring sentences - edited based on number of reviews for a film
#gets the sentence ids of the most important sentences - ids used to identify the original sentences - with punctuation etc
most_important_ids = sorted_importance_ids[:top_n_sentences] # stores ids of highest scoring sentences

pre_processed_sentences = sent_tokenize(text) # original reviews split into separate sentences, include original punctuation word stems etc
print("\nSUMMARY OF REVIEWS: \n")
for sentence_id in most_important_ids: # for each id , checks if it is classed as an important id
    print(pre_processed_sentences[sentence_id]) # prints full sentences rather than cleaned sentence