#Code used to produce the grouped bar charts

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

file_name = "Path\\To\\File\\Algos_Results.xlsx"
df = pd.read_excel(io=file_name) # reads in dataset and stores in dataframe df
df = df.dropna() # drop na values from df
labels = df['Algorithms']
accuracy = df['Accuracy']
f1 = df['F1 Score']

x = np.arange(len(labels))  
width = 0.35  

fig, ax = plt.subplots()
rects1 = ax.bar(x - width/2, accuracy, width, label='Accuracy')
rects2 = ax.bar(x + width/2, f1, width, label='F1 Score')

ax.set_ylabel('%_Level')
ax.set_title('Accuracy & F1 Scores of Classification Algorithms')
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=90)
ax.legend()


def autolabel(rects):
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),
                    ha='center', va='bottom')


autolabel(rects1)
autolabel(rects2)

fig.tight_layout()

plt.show()
