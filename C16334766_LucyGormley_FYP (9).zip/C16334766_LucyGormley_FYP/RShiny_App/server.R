library(tidyverse)
library(stringr)
library(shiny)
library(DT)
library(ggplot2)
library(shinyWidgets)
library(readxl)
library(lubridate)
library(dygraphs)
library(dplyr)
library(xts)
library(janitor)

# packages janitor and xts often presented many issues when importing, may need to delete older versions of these and redownload to run fully


movie_reviews<-read_excel("Reviews_Data.xlsx")#read in data - main data
nominations<-read_excel("Winners_Nominees_List.xlsx")#read in data - list of nominees winners - tab 3
nominations$Award_Year <- as.factor(nominations$Award_Year)
nominations$Film_Title_List <- as.factor(nominations$Film_Title_List)
nominations$Win_OR_Lose <- as.factor(nominations$Win_OR_Lose)

movie_reviews$Date <- substr(movie_reviews$Date, 0, 10)
movie_reviews$Review_Year <- substr(movie_reviews$Date, 0, 4)
movie_reviews$Date =  as.Date(movie_reviews$Date, format = "%Y-%m-%d")
movie_reviews$Rating <- as.factor(movie_reviews$Rating)
movie_reviews$Award_Year <- as.factor(movie_reviews$Award_Year)
movie_reviews$Film_Title_With_Year_Selection <- as.factor(movie_reviews$Film_Title_With_Year_Selection)
films<-unique(movie_reviews$Film)

shinyServer(function(input, output) {
  
  #User Instructions heading
  output$instructions <- renderText({
    paste("Overview of Dashboard and User Instructions")
  })
  
  #List of user instructions
  output$text_instructions <- renderUI({
    HTML(paste("The dashboard page contains the collected user reviews for all films who won or were nominated for an Academy Award (Oscars) for Best Picture between 2001 and 2020.",
               "",
               "FILTERING OVERVIEW",
               "Filter data table or plot by date range selector.",
               "Filter fields by using the search bars above each field in the data table.",
               "Text search filters applied in the data table will also be applied to the charts.",
               "Filter by dates first as editing the date range selctor will reset all filters applied within the data table.",
               "",
               "SEARCH REVIEWS BY OR / AND LOGIC",
               "Filter user reviews by entering various search terms in the search bar above the datatable or the filter bar above the Review column.",
               "- Example (OR LOGIC): (value_1|value_2|value_3) ",
               "-> Applied Example: (amazing|oscar|award)",
               "- Entering the above example - including the OR bar(|) and brackets - will return all user reviews that contain either amazing or oscar or award
               in the text column of user reviews.",
               "- Example (AND LOGIC): value_1 value_2 value_3 ",
               "-> Applied Example: amazing oscar award",
               "- Entering the above example - without the OR bar (|) and brackets - will return all applications that contain all 3 words: amazing and oscar and award
               in the text column of user reviews.",
               "",
               "DOWNLOAD FILTERED DATA",
               "Download filtered data to .csv file using the download button in the side panel.",
               "- The filtered rows returned in the data table, will be written to the downloaded file.",
               "- All columns of data will be written to the downloaded file, even if the column is unticked in the side panel.",
               sep="<br/><br/>"))
  })
  
  #allow user to pick columns to view in the datatable, Data() used in datatable
  Data <- reactive({
    if(input$radio == "All"){
      movie_reviews
    } else {
      movie_reviews[,input$show_vars,drop=FALSE]
    }
  })
  
  Data_films <- reactive({
    nominations
  })
  
  Filtered_data <- reactive({
    movie_reviews%>% filter(
      Date >= input$dateRange[1] & Date <= input$dateRange[2])
  })
  
  # Creates barplot for count v variable chosen by user
  #table_rows_all parameter ensures only records returned in the filtered table are used for the plot
  output$barplot <- renderPlot({
    ggplot(data = subset(Filtered_data()[input[["table_rows_all"]], ], !is.na(Filtered_data()[input[["table_rows_all"]], ][input$x])), aes_string(x=input$x, fill = input$x)) +
      geom_bar() +
      labs(x = str_replace_all(input$x, "_", " "),
           y = "Volume of Reviews",
           color = str_replace_all(input$z, "_", " "),
           title = paste("Volume of User Reviews Grouped By", str_replace_all(input$x, "_", " "), "Variable", sep = " ")
      )+
      theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))
  })
  # datatable - search regex allows user to input search terms by OR / AND logic - outlined in user instructions tab
  # dynamic search feature that isnt fulfilled through Usual IMDB site
  output$table <- DT::renderDataTable(
    DT::datatable(filter='top',Data()%>% filter(
      Date >= input$dateRange[1] & Date <= input$dateRange[2]),
      extensions =
        list('ColReorder' = NULL,
             'FixedHeader' = NULL,
             'KeyTable' = NULL),
      options = list(search=list(regex=TRUE),
                     colReorder = TRUE,
                     fixedHeader = TRUE,
                     keys = TRUE
      ))
  )
  
  output$table_films <- DT::renderDataTable(
    DT::datatable(filter='top',Data_films(),
      extensions =
        list('ColReorder' = NULL,
             'FixedHeader' = NULL,
             'KeyTable' = NULL),
      options = list(search=list(regex=TRUE),
                     colReorder = TRUE,
                     #fixedHeader = TRUE,
                     keys = TRUE
      ))
  )
  # Counts number of rows in fitered datatable
  output$description <- renderText({
    paste(nrow(movie_reviews[input[["table_rows_all"]], ]), " rows returned in the Data Table. Please use filter bars above each field in the data table below to narrow your search.")
  })
  output$dateRangeText  <- renderText({
    paste("input$dateRange is",
          
          paste(as.character(input$dateRange), collapse = " to ")
    )
  })
  #downloads filtered datat from DT to .csv file (includes all columns, even if unticked)
  output$downloadFilter <- downloadHandler(
    filename = function() {
      paste0("Filtered_Movie_Data.csv")
    },
    content = function(file){
      write.csv(Filtered_data()[input[["table_rows_all"]], ],
                file= file,
                row.names=F)
    }
  )
  
  output$dygraph <- renderDygraph({
    #table calculated to count number of reviews for positive & negative reviews
    #linked to the Date variable to allow for user interaction
    #dygraph and xts package used here
    
    film_choice<-input$Films
    
    z1<-subset(movie_reviews, Film == film_choice)
    
    z1<-z1[!is.na(z1$Rating),]
    
    z2<-z1%>%
      filter(Pos_Neg_Label == "1")
    z3<-tabyl(z2$Date, sort = TRUE)
    
    z3<-z3[,-3]
    
    colnames(z3)[1]<-("Date")
    colnames(z3)[2]<-("Volume of Positive")
    Positive<-z3
    z3xts <- xts(z3[,-1], order.by=z3$Date)
    colnames(z3xts)[1]<-("Number_Positive_Reviews")
    str(z3xts)   
    
    Number_Positive_Reviews <-z3xts$Number_Positive_Reviews
    z2<-z1 %>% filter(Pos_Neg_Label == "0") 
    z3<-tabyl(z2$Date, sort = TRUE)
    z3<-z3[,-3]
    colnames(z3)[1]<-("Date")
    colnames(z3)[2]<-("Volume of Negative")
    Negative<-z3
    
    z3xts <- xts(z3[,-1], order.by=z3$Date)
    colnames(z3xts)[1]<-("Number_Negative_Reviews")
    Number_Negative_Reviews <-z3xts$Number_Negative_Reviews
    # Bring Positive and negative together
    total <- merge(Positive,Negative,by="Date")
    z3<-total
    z3xts <- xts(z3[,-1], order.by=z3$Date)
    Max1<-max(Positive$Number_Positive)
    Max2<-max(Negative$Number_Negative)
    if (Max2>Max1) {limit=Max2*1.1} # ensure range in graph is relative to the number f reviews for each film - Joker would distort other charts given its high vol reviews
    if (Max1>=Max2) {limit=Max1*1.1} # by 1.1 to allow for a little extra range along y axis
    
    #runs the time series graph
    dygraph(z3xts, main = (film_choice))%>%
      dyAxis("y", label = "Number Of Reviews", valueRange = c(0, limit), independentTicks = TRUE)%>%
      dyAxis("y2", label = "Volume Of Negative", valueRange = c(0, limit), independentTicks = TRUE) %>%
      dySeries("Volume of Positive", axis=('y')) %>%
      dyRangeSelector(height = 50)%>%
      dyOptions(drawGrid = input$showgrid)
    
  })
  
  output$from <- renderText({
    strftime(req(input$dygraph_date_window[[1]]), "%d %b %Y") # displays overall filtered timeline from time series graph     
  })
  
  output$to <- renderText({
    strftime(req(input$dygraph_date_window[[2]]), "%d %b %Y")
  })
}
)
