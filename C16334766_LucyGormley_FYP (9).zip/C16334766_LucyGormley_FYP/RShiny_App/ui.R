library(tidyverse)
library(stringr)
library(shiny)
library(DT)
library(ggplot2)
library(shinyWidgets)
library(readxl)
library(lubridate)
library(dygraphs)
library(dplyr)
library(xts)
library(janitor)

movie_reviews<-read_excel("Reviews_Data.xlsx")#read in data
nominations<-read_excel("Winners_Nominees_List.xlsx")#read in data
nominations$Award_Year <- as.factor(nominations$Award_Year)
nominations$Film_Title_List <- as.factor(nominations$Film_Title_List)
nominations$Win_OR_Lose <- as.factor(nominations$Win_OR_Lose)

movie_reviews$Date <- substr(movie_reviews$Date, 0, 10)
movie_reviews$Review_Year <- substr(movie_reviews$Date, 0, 4)
movie_reviews$Date =  as.Date(movie_reviews$Date, format = "%Y-%m-%d")
movie_reviews$Rating <- as.factor(movie_reviews$Rating)
movie_reviews$Award_Year <- as.factor(movie_reviews$Award_Year)
movie_reviews$Film_Title_With_Year_Selection <- as.factor(movie_reviews$Film_Title_With_Year_Selection)
films<-unique(movie_reviews$Film)


shinyUI(fluidPage(
  titlePanel("Audience Opinion Analysis"),
  setBackgroundColor("lavender"),
  tabsetPanel(type = "tabs",
              tabPanel("Dashboard",
                       sidebarLayout(position = "left",
                                     sidebarPanel(
                                       wellPanel(h3("Plotting"),      # Third level header: Plotting
                                                 h5("Narrow search by using filters above each field in the data table (either before or after choosing your chart option)"),
                                                 # Select variable for x-axis
                                                 selectInput(inputId = "x",
                                                             label = "X-axis:",
                                                             choices = c("User Review Ratings - Filter by Film" = "Rating", "Volume of Reviews by Film - Filter by Award_Year" = "Film",
                                                                         "Volume of Reviews by Year - Filter by Film" = "Review_Year", "Positive / Negative Review Counts - Filter by Film" = "Positive_OR_Negative"
                                                             ),
                                                             selected = "User Review Score")
                                       ),
                                       wellPanel(h3("Date Filter"),
                                                 h5("*Using this date selector will reset other filters previously applied in the data table*"),
                                                 dateRangeInput('dateRange',
                                                                label = 'Filter by Review Date',
                                                                start = as.Date('2000-01-01'), end = Sys.Date())
                                       ),
                                       wellPanel(downloadButton('downloadFilter',"Download Filtered Data")),
                                       wellPanel(radioButtons(
                                         inputId="radio",
                                         label="Variable Selection Type:",
                                         choices=list(
                                           "All",
                                           "Manual Select"
                                         ),
                                         selected="Manual Select"),
                                         conditionalPanel(
                                           condition = "input.radio != 'All'",
                                           checkboxGroupInput(
                                             'show_vars',
                                             'Columns to View:',
                                             choices=names(movie_reviews),
                                             selected = c("Film_Title_With_Year_Selection","Award_Year","Date", "Win"))
                                         ))
                                     ),
                                     mainPanel(h2("Plot"), plotOutput("barplot"),br(),h2("Data Table"),br(),
                                               h4(textOutput("description")),
                                               br(),
                                               DT::dataTableOutput(outputId = "table")
                                     ))),
              tabPanel("Time Series",
                       sidebarLayout(
                         sidebarPanel(
                           wellPanel(h5("Select a film to view a time series graph for."),
                           selectInput("Films", "List of Films:",
                                      choices=films)),
                           checkboxInput("showgrid", label = "Show Grid", value = TRUE),
                           hr(),
                           div(strong("From: "), textOutput("from", inline = TRUE)),
                           div(strong("To: "), textOutput("to", inline = TRUE)),
                           br(),
                           helpText("Click and drag to zoom in (double click to zoom back out). Alternatively, the scale beneath the graph can be used to view chart in finer detail.")
                         ),
                         mainPanel(h2("Timeline Displays Volume of Positive & Negative Reviews"),
                           dygraphOutput("dygraph")
                         )
                       )),
              tabPanel("Winners & Nominees",
                         mainPanel(
                           DT::dataTableOutput(outputId = "table_films")
                         
                       )),
              tabPanel("Instructions",h3(textOutput("instructions")),br(),h5(htmlOutput("text_instructions")))
              
              )))
