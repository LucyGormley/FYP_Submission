from wordcloud import WordCloud
import matplotlib.pyplot as plt 
import pandas as pd 
import nltk
from nltk.corpus import stopwords
import numpy as np
  
#file_name='C:\\Path\\To\\File\\Reviews_Data.xlsx'
file_name =  "C:\\Users\\Lucy\\College\\4th Year\\FYP\\Sentiment\\Data_For_ML_Model.xlsx"
df = pd.read_excel(io=file_name) # store in dataframe df
df = pd.DataFrame(df)
df = df.loc[df['Film'] == "Joker"]#focus on Joker film
df = df.loc[df['Rating'] < 3] # view exteremly negative review words
#df = df.loc[df['Rating'] > 8] # view exteremly positive review words
df = df[['Review']] # only need to look at reviews column now


review_words = '' 
stopwords = nltk.corpus.stopwords.words('english')
#append words to stopword list based on director and actor names etc that may pop up, and wouldnt be included in generic stopwords list
newStopWords = ['movie','film','joaquin','film','joker','phoenix','see','scene','good','arthur','think','even','sharon','tate','character','one','like','story','get','way','make']
stopwords.extend(newStopWords)
  
for index, row in df.iterrows():  
    review = row[0] #text column - contains review
    review = str(review) #convert all values to strings - eg reviews may start with numbers eg 1917
    sentences = review.split() # split the review into sentences
    
    # Converts each sentence into lowercase 
    for i in range(len(sentences)): 
        sentences[i] = sentences[i].lower() 
      
    review_words += " ".join(sentences)+" "
  
wordcloud = WordCloud(width = 800, height = 800, 
                background_color ='white', 
                stopwords = stopwords, 
                min_font_size = 10).generate(review_words) 

def grey_color_func(word, font_size, position,orientation,random_state=None, **kwargs):
    return("hsl(230,100%%, %d%%)" % np.random.randint(0,20)) # formatting wordcloud


wordcloud.recolor(color_func = grey_color_func)                       
plt.figure(figsize = (8, 8), facecolor = None) 
plt.imshow(wordcloud) 
plt.axis("off") 
plt.tight_layout(pad = 0) 
  
plt.show() #display final wordcloud