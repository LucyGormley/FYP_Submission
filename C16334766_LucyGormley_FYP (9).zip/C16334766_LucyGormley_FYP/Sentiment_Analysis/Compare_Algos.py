#assisted by the follwoing website

import pandas as pd
from sklearn.feature_selection import chi2
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_val_score
import seaborn as sns
from IPython.display import display
#import matplotlib as plt

#models thtat will be compared
models = [
    RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0)
]

file_name='C:\\Path\\To\\File\\Data\\Reviews_Data.xlsx'

df = pd.read_excel(io=file_name) # store in dataframe df

#tidy up dataframe for use
df = df.loc[df['Award_Year'] == 2019]#if memory error pops up, can run on subset of data for quicker run time example
df2 = df[['Review', 'Pos_Neg_Label']]
df['Review'] = df['Review'].str.replace('\d+', '')

col = ['Pos_Neg_Label', 'Review']
df = df[col]
df = df[pd.notnull(df['Review'])]
df.columns = ['Pos_Neg_Label', 'Review']

#assign labels to compare results to
df['Label_ID'] = df['Pos_Neg_Label'].factorize()[0]
binary_id_df = df[['Pos_Neg_Label', 'Label_ID']].drop_duplicates().sort_values('Label_ID')
binary_to_id = dict(binary_id_df.values)
id_to_binary = dict(binary_id_df[['Label_ID', 'Pos_Neg_Label']].values)
df.tail()

#set up tfidf vecterizer to convert text data to numerical
tfidf = TfidfVectorizer(sublinear_tf=True, min_df=5, norm='l2', encoding='latin-1', ngram_range=(1, 2), stop_words='english')
features = tfidf.fit_transform(df.Review).toarray()
labels = df.Label_ID
features.shape

N = 2
for Pos_Neg_Label, Label_ID in sorted(binary_to_id.items()):
  features_chi2 = chi2(features, labels == Label_ID)
  indices = np.argsort(features_chi2[0])
  feature_names = np.array(tfidf.get_feature_names())[indices]
  unigrams = [v for v in feature_names if len(v.split(' ')) == 1]
  bigrams = [v for v in feature_names if len(v.split(' ')) == 2]


#split into training, testing data
X_train, X_test, y_train, y_test = train_test_split(df['Review'], df['Pos_Neg_Label'], random_state = 0)
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(X_train)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
clf = MultinomialNB().fit(X_train_tfidf, y_train)

#carry out classification by looping through list of models
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))
entries = []
for model in models:
  model_name = model.__class__.__name__
  accuracies = cross_val_score(model, features, labels, scoring='accuracy', cv=CV)
  for fold_idx, accuracy in enumerate(accuracies):
    entries.append((model_name, fold_idx, accuracy))
    
cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])
ax = sns.boxplot(x='model_name', y='accuracy', data=cv_df)
ax = sns.stripplot(x='model_name', y='accuracy', data=cv_df, 
              size=8, jitter=True, edgecolor="gray", linewidth=2)

#can run these plots separately at the end, commented out for now
# plt.setp(ax.get_xticklabels(), rotation=45)
# ax.set_title('Model Prediction Accuracy Levels')
# ax.set_ylabel('Accuracy Levels')
# ax.set_xlabel('Classification Model')
# plt.show()

print(cv_df.groupby('model_name').accuracy.mean())

model = RandomForestClassifier()
X_train, X_test, y_train, y_test, indices_train, indices_test = train_test_split(features, labels, df.index, test_size=0.33, random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
conf_mat = confusion_matrix(y_test, y_pred)
#run plot separately at end
# ax = plt.subplots(figsize=(10,10))
# sns.heatmap(conf_mat, annot=True, fmt='d',
#             xticklabels=binary_id_df.Pos_Neg_Label.values, yticklabels=binary_id_df.Pos_Neg_Label.values)
# plt.ylabel('Actual')
# plt.xlabel('Predicted')
# plt.show()

#testing data based on a third of dataset
#number of false predictions
for predicted in binary_id_df.Label_ID:
  for actual in binary_id_df.Label_ID:
    if predicted != actual and conf_mat[actual, predicted] >= 10:
      print("'{}' predicted as '{}' : {} examples.".format(id_to_binary[actual], id_to_binary[predicted], conf_mat[actual, predicted]))
      #display(df.loc[indices_test[(y_test == actual) & (y_pred == predicted)]][['Pos_Neg_Label', 'Review']])
      print('')

#number of correct predictions      
for predicted in binary_id_df.Label_ID:
  for actual in binary_id_df.Label_ID:
    if predicted == actual and conf_mat[actual, predicted] >= 10:
      print("'{}' predicted as '{}' : {} examples.".format(id_to_binary[actual], id_to_binary[predicted], conf_mat[actual, predicted]))
      #display(df.loc[indices_test[(y_test == actual) & (y_pred == predicted)]][['Pos_Neg_Label', 'Review']])
      print('')