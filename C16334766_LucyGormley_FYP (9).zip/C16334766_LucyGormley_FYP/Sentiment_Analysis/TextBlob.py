import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from textblob import TextBlob

file_name='C:\\Path\\To\\File\\Data\\Reviews_Data.xlsx'
df = pd.read_excel(io=file_name) # reads in dataset and stores in dataframe df
df = df.dropna() # drop na values from df

stopwords_list = stopwords.words('english')
sentiment_list = [] # list to store polarity scores
binary_list = [] # list to store binary scores
stemmer = nltk.stem.SnowballStemmer("english") #get snowball stemmer ready


#find polarity scores of each review
#written as method to increase speed of script
def sentiment_textblob(feedback): 
	senti = TextBlob(feedback) 
	polarity = senti.sentiment.polarity 
	return (polarity)
 

#process the reviews, loop through each row on the text column
for index, row in df.iterrows():
    processed_sentence = row[6] ##text column - contains review 
    processed_sentence = str(processed_sentence) # convert reviews to text type - incase review starts with digit e.g 1917 film might
    processed_sentence = re.sub(r'[0-9]','', processed_sentence) # remove numbers as they dont have an effect on sentiment / polarity
    processed_sentence = processed_sentence.lower() # convert all words to lower case
    processed_sentence = processed_sentence.replace('\n',' ') # replace next line notation with blank space
    processed_sentence = processed_sentence.replace('_',' ') # replace underscore with blank space
    processed_sentence = re.sub(r'[^\w\s]','', processed_sentence)# removes characters that are not words
    processed_sentence = stemmer.stem(processed_sentence) # leaves the stem of words 
    processed_sentence = [w for w in processed_sentence.split() if not w in stopwords_list] #join words back together if theyre not a stopword
    processed_sentence = " ".join(processed_sentence) # join sentences back together
    processed_sentiment = sentiment_textblob(processed_sentence)#run sentiment classifier on cleaned sentence - maximise chance of accurate polarity scoring
    if processed_sentiment >= 0.2: # if polarity is classed as above neutral, sentence is positive
        binary = 1
    else:
        binary = 0 # otherwise, sentence is negative
        
    sentiment_list.append(processed_sentiment) # stores list of polarity sentiment scores
    binary_list.append(binary) # stores list of binary classifiers - 0 or 1


sentiment_df = pd.DataFrame(sentiment_list) # convert to dataframe
binary_df = pd.DataFrame(binary_list)
df.insert(10, 'TextBlob_Polarity', sentiment_df) # insert lists into original dataframe
df.insert(11, 'TextBlob_Binary', binary_df)

print(len(sentiment_df)) # verify successful completion by checking lengths of dfs
print(len(df))


df.to_excel("C:\\Path\\To\\File\\TextBlob.xlsx") # write df to excel

