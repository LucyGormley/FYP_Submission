import pandas as pd
import nltk
import numpy as np
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import re
from nltk.corpus import stopwords

file_name='C:\\Path\\To\\File\\Data\\Reviews_Data.xlsx'
df = pd.read_excel(io=file_name) # store in dataframe df
df = df.dropna()

#df['Review'] = df['Review'].astype(str)
analyser = SentimentIntensityAnalyzer()
df = df.loc[df['Award_Year'] == 2001] # subset to increase speed for example testing

stopwords_list = stopwords.words('english')
sentiment_list = [] # list to store polarity scores
binary_list = [] # list to store binary scores
stemmer = nltk.stem.SnowballStemmer("english") #get snowball stemmer ready

compval1 = [ ]  #empty list to hold our computed 'compound' VADER scores

#process the reviews, loop through each row on the text column
for index, row in df.iterrows():
    processed_sentence = row[6] ##text column - contains review 
    processed_sentence = str(processed_sentence) # convert reviews to text type - incase review starts with digit e.g 1917 film might
    processed_sentence = re.sub(r'[0-9]','', processed_sentence) # remove numbers as they dont have an effect on sentiment / polarity
    processed_sentence = processed_sentence.lower() # convert all words to lower case
    processed_sentence = processed_sentence.replace('\n',' ') # replace next line notation with blank space
    processed_sentence = processed_sentence.replace('_',' ') # replace underscore with blank space
    processed_sentence = re.sub(r'[^\w\s]','', processed_sentence)# removes characters that are not words
    processed_sentence = stemmer.stem(processed_sentence) # leaves the stem of words 
    processed_sentence = [w for w in processed_sentence.split() if not w in stopwords_list] #join words back together if theyre not a stopword
    processed_sentence = " ".join(processed_sentence) # join sentences back together
    processed_sentiment = analyser.polarity_scores(processed_sentence)
    compval1.append(processed_sentiment['compound'])


compval2 = np.array(compval1)

df['VADER score'] = compval1
i = 0
predicted_value = [ ]

#assign binary labels
while(i<len(df)):
    if ((df.iloc[i]['VADER score'] >= 0.2)):
        predicted_value.append(1)
        i = i+1
    elif ((df.iloc[i]['VADER score'] < 0.2)):
        predicted_value.append(0)
        i = i+1
        
df['predicted sentiment'] = predicted_value # column to store Vader binary labels
Correct_Predictions = df[df['Pos_Neg_Label'] == df['predicted sentiment']] # where predicted label equals original label
df.to_excel("C:/Users/Lucy/College/4th Year/FYP/Submission/C16334766_LucyGormley_FYP/Sentiment_Analysis/Vader.xlsx")
