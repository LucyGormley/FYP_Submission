#subfile of webscraper to run scrpaer quickly without issues associated with hitting the site - less data to be collected
#I used a VPN to allow for extra protection of my IP address when using the scraper

import os
import pandas as pd
import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
import numpy as np

os.chdir('C:\\Path\\To\\File\\With\\ChromeDriverExeFile\\Webscraper') # change to directory  

titles = [] # set up empty lists
dates = []
reviews = []

SITE="https://www.imdb.com/title/tt6966692/reviews?sort=helpfulnessScore&dir=desc&ratingFilter=7" # store site to be retreived and scraped

#set path for Chrome driver executable file - version of chrome may change type of .exe file needed - chrome version 83 exe file included
driver = webdriver.Chrome("C:/Users/Lucy/College/4th Year/FYP/WebScraper/chromedriver.exe")
driver.get(SITE) # navigate to website
wait = WebDriverWait(driver,2)#to allow time for element/button to load

#click all load more buttons first
while True:
    try:
        element = wait.until(EC.element_to_be_clickable((By.ID, 'load-more-trigger')))#identify next page button by ID
        element.click()#click next page button
        time.sleep(5) # allow for time to load
    except TimeoutException:
        break

#click all unhide spoiler buttons next
spoiler_buttons = driver.find_elements_by_class_name('expander-icon-wrapper.spoiler-warning__control')
for spoiler in spoiler_buttons:
    spoiler.click
    time.sleep(3) # allow for time to click then load

#collect all date values and append to dates list
all_dates = driver.find_elements_by_class_name('review-date')
for date in all_dates:
    date = date.text
    dates.append(date)
    time.sleep(1)

#collect all review title values and append to titles list
all_titles = driver.find_elements_by_class_name('title')
for title in all_titles:
    title = title.text
    titles.append(title)
    time.sleep(1)

#collect all review values and append to reviews list    
all_reviews = driver.find_elements_by_class_name('text.show-more__control')
for review in all_reviews:
    review = review.text
    reviews.append(review)
    time.sleep(1)

#close driver window
time.sleep(1)
driver.close()
 
#titles list always collects 1 empty value at the end of scraping, remove it now   
titles = titles[:-1]
#creat dataframe of 3 scraped lists
df = pd.DataFrame(np.column_stack([dates, titles, reviews]), 
                                columns=['Date', 'Title', 'Review'])
#insert required columns
df['Rating'] = 7
df['Film'] = 'Green Book'
df['Award_Year'] = '2019'
#write to excel 
df.to_excel("C:/Users/Lucy/College/4th Year/FYP/Submission/C16334766_FYP_DT3024/Data_scraped.xlsx")
