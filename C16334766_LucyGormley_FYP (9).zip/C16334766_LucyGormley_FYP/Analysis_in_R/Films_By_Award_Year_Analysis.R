rm(list=ls())
setwd('C:\\Users\\Lucy\\College\\4th Year\\FYP\\RShiny_App\\WebAppFinal\\Audience_Opinion_Films')
getwd()

# check files in the directory
list.files(path = ".", pattern = NULL, all.files = FALSE,
           full.names = FALSE, recursive = FALSE,
           ignore.case = FALSE, include.dirs = FALSE, no.. = FALSE)

library(dplyr)
library("readxl")
library(xts)
library(janitor)
library(ggplot2)

#janitor and xts often have issues with being imported, may need to delete old versions and reinstall the packages

z4<-read_excel("Reviews_Data.xlsx")#read in data
Date_1<-"2001-01-01" # set date limits
Date_2<-"2020-03-10"

z1<-z4[,c(2,4,5,6,7,8,3,10)]
z1<-z1%>%
  filter(Date >= Date_1 & Date <= Date_2)
str(z1)

z2<-z1[,c(1,7)]
Year_Film<-unique(z2)
Year_Film<-Year_Film[order(Year_Film$Film),]

z1<-z1[!is.na(z1$Rating),]

z2<-z1%>%
  filter(Pos_Neg_Label == "1")

  z3<-tabyl(z2$Film, sort = TRUE)
  z3<-z3[,-3]# takes out 3rd column

colnames(z3)[1]<-("Film")
colnames(z3)[2]<-("Number_Positive")
Positive<-z3
Positive<-Positive[order(Positive$Film),]


z2<-z1 %>% filter(Pos_Neg_Label == "0") 
z3<-tabyl(z2$Film, sort = TRUE)
z3<-z3[,-3]
colnames(z3)[1]<-("Film")
colnames(z3)[2]<-("Number_Negative")
Negative<-z3
Negative<-Negative[order(Negative$Film),]

Table <- left_join(Year_Film, Positive, by='Film') %>%
  left_join(., Negative, by='Film') 

Table <- Table %>% mutate(Total_Reviews= (Number_Positive+Number_Negative), Percent_Pos = Number_Positive*100/Total_Reviews, Percent_Neg = Number_Negative*100/Total_Reviews, Diff_Pos_Neg = Percent_Pos-Percent_Neg)

Table$Percent_Pos<-round(Table$Percent_Pos, digits=2)
Table$Percent_Neg<-round(Table$Percent_Neg, digits=2)
Table$Diff_Pos_Neg<-round(Table$Diff_Pos_Neg, digits=2)

table(Table$Award_Year)
# Filter for year
choice=2020
Table_Choice<-Table%>%
  filter(Award_Year == choice)
  View(Table_Choice)
  
  # preparation for pareto chart

  # Create dataframe with the data
  myDf <- data.frame(testvar=Table_Choice$Number_Negative,
                     Film=Table_Choice$Film,
                     stringsAsFactors = FALSE)
  str(myDf)
  # Order the data by the variable - pos/ neg
  myDf <- myDf[order(myDf$testvar, decreasing=TRUE), ]


  # Converting the categorical variable to a factor
  myDf$Film <- factor(myDf$Film, levels=myDf$Film)

  #Adding a cumulative sum to the data frame
  myDf$cumulative <- cumsum(myDf$testvar)

  # Create multipliers to even out values on the axes
  numfact = nlevels(myDf$Film)
  mult<-numfact/6
  maxm<-max(myDf$cumulative)
  fact<-max(myDf$cumulative)/100
  
  
  title1<-"Volume of Negative Reviews - 2020"
  
  i2 <- "Pareto"
  today <- Sys.Date()
  today<-format(today, format="%B %d %Y")

  g <- ggplot(myDf, aes(x=myDf$Film)) +
    geom_bar(aes(y=myDf$testvar), fill='blue', stat="identity") +
    geom_point(aes(y=myDf$cumulative/mult), color = rgb(0, 1, 0), pch=16, size=1) +
    geom_path(aes(y=myDf$cumulative/mult, group=1), colour="slateblue1", lty=3, size=0.9) +
    theme(axis.text.x = element_text(angle=90, vjust=0.6)) +
    scale_y_continuous(title1, sec.axis = sec_axis(~.*mult/fact, name = "Cumulative (%)")) +
    theme(plot.title = element_text(color="Dark Blue", face="bold", size=19, hjust = 0.5)) +
    labs(title = paste("Pareto Chart - ", title1), x = 'Film')
  g
  
  myDf2 <- data.frame(Table_Choice[,1],
                      Table_Choice[,6],
                      Table_Choice[,7],
                      stringsAsFactors = FALSE)
  library(reshape2)
  myDf2.long<-melt(myDf2,id.vars="Film")
  
  title2<-"Percentage of Positive and Negative Reviews - 2020"
 g<- ggplot(myDf2.long,aes(x=Film,y=value,fill=factor(variable)))+
    geom_bar(stat="identity",position="dodge") +
    theme(axis.text.x = element_text(angle=90)) +
    labs(title = paste(title2), x = 'Film', y='Percentage of Reviews') + 
    theme(legend.title = element_blank())+
    theme(plot.title = element_text(hjust = 0.5))
  
  g
    
    